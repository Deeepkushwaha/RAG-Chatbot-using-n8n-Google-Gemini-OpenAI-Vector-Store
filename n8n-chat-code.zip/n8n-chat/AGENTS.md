<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

## Architecture decisions

- n8n webhook calls are proxied through the server route `src/routes/api/public/n8n-chat.ts` (POST `{ url, message, sessionId }`) — never fetch the n8n webhook from the browser directly, it avoids CORS and keeps the request shape (n8n Chat Trigger `{ action: "sendMessage", chatInput }`) in one place.
- Chat threads persist in browser localStorage with independent session IDs and route-derived active IDs at `/chat/$threadId`; migrate legacy single-chat history once to preserve existing conversations.
- Shared chat state lives in a browser-hydrated provider around the root Outlet so switching thread URLs preserves connection settings and pending replies.
- Keep the existing n8n JSON proxy transport rather than adding AI SDK server streaming: the upstream workflow owns model behavior and returns complete replies; use AI Elements for the visible chat controls.

