import { createFileRoute } from "@tanstack/react-router";
import { ChatHome } from "@/components/chat/chat-home";

export const Route = createFileRoute("/chat/$threadId")({
  head: () => ({
    meta: [
      { title: "Conversation — n8n Chat" },
      {
        name: "description",
        content: "Continue your saved n8n conversation in your personal chat workspace.",
      },
      { property: "og:title", content: "Conversation — n8n Chat" },
      {
        property: "og:description",
        content: "Continue your saved conversation with your n8n workflow.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ChatPage,
});
function ChatPage() {
  const { threadId } = Route.useParams();
  return <ChatHome key={threadId} threadId={threadId} />;
}
