import { createFileRoute } from "@tanstack/react-router";
import { ChatHome } from "@/components/chat/chat-home";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "n8n Chat — Your personal workspace" },
      {
        name: "description",
        content: "Chat with your n8n assistant and revisit your browser-saved conversations.",
      },
      { property: "og:title", content: "n8n Chat — Your personal workspace" },
      { property: "og:description", content: "A personal chat workspace for your n8n workflows." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: () => <ChatHome />,
});
