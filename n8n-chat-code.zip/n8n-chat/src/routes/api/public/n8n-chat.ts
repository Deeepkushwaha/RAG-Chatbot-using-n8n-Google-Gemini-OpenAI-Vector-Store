import { createFileRoute } from "@tanstack/react-router";
import { z } from "zod";

const bodySchema = z.object({
  url: z
    .string()
    .url()
    .refine((u) => /^https?:\/\//i.test(u), "Must be an http(s) URL"),
  message: z.string().min(1).max(10_000),
  sessionId: z.string().min(1).max(200),
});

function pickReply(value: unknown, depth = 0): string | null {
  if (depth > 6) return null;
  if (typeof value === "string") return value;
  if (Array.isArray(value)) {
    for (const item of value) {
      const found = pickReply(item, depth + 1);
      if (found) return found;
    }
    return null;
  }
  if (value && typeof value === "object") {
    const obj = value as Record<string, unknown>;
    for (const key of ["output", "text", "message", "reply", "content", "data", "choices"]) {
      if (key in obj) {
        const found = pickReply(obj[key], depth + 1);
        if (found) return found;
      }
    }
  }
  return null;
}

/**
 * Extract the assistant reply from an n8n Chat Trigger response.
 * Handles plain text, JSON objects (output/text/message/data), and
 * NDJSON streaming responses ({ "type": "item", "content": "..." } lines).
 */
function extractReply(raw: string): string {
  const trimmed = raw.trim();
  if (!trimmed) return "";

  const lines = trimmed.split("\n").filter((l) => l.trim().length > 0);
  if (lines.length > 1) {
    const parts: string[] = [];
    let allParsed = true;
    for (const line of lines) {
      try {
        const obj = JSON.parse(line) as { content?: unknown; type?: unknown };
        const content = typeof obj["content"] === "string" ? obj["content"] : null;
        if (content !== null) {
          if (obj["type"] === "item" || obj["type"] === undefined) parts.push(content);
        } else {
          allParsed = false;
          break;
        }
      } catch {
        allParsed = false;
        break;
      }
    }
    if (allParsed && parts.length > 0) return parts.join("");
  }

  try {
    const obj = JSON.parse(trimmed) as unknown;
    const found = pickReply(obj);
    if (found != null) return found;
  } catch {
    // plain text response
  }
  return trimmed;
}

export const Route = createFileRoute("/api/public/n8n-chat")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        let json: unknown;
        try {
          json = await request.json();
        } catch {
          return Response.json({ error: "Invalid request body." }, { status: 400 });
        }

        const parsed = bodySchema.safeParse(json);
        if (!parsed.success) {
          return Response.json(
            { error: "n8n webhook URL, message aur sessionId required hain." },
            { status: 400 },
          );
        }
        const { url, message, sessionId } = parsed.data;

        let upstream: Response;
        try {
          upstream = await fetch(url, {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              "x-session-id": sessionId,
            },
            body: JSON.stringify({ action: "sendMessage", sessionId, chatInput: message }),
            signal: AbortSignal.timeout(120_000),
          });
        } catch {
          return Response.json(
            {
              error:
                "n8n webhook URL tak request nahi pahunchi. URL check karo aur confirm karo ki workflow active hai.",
            },
            { status: 502 },
          );
        }

        const raw = await upstream.text();
        const reply = extractReply(raw);

        if (!upstream.ok) {
          return Response.json(
            {
              error: `n8n ne ${upstream.status} status return kiya. Workflow ka response check karo.`,
              reply: raw ? reply : undefined,
            },
            { status: 200 },
          );
        }

        return Response.json({ reply });
      },
    },
  },
});
