import type { UIMessage } from "ai";

export type ChatThread = { id: string; title: string; updatedAt: number; messages: UIMessage[] };
export const THREADS_KEY = "n8n-chat:threads";
export const WEBHOOK_KEY = "n8n-chat:webhook-url";
export function makeThread(): ChatThread {
  return { id: crypto.randomUUID(), title: "New chat", updatedAt: Date.now(), messages: [] };
}
export function messageText(message: UIMessage): string {
  return message.parts
    .filter((p) => p.type === "text")
    .map((p) => p.text)
    .join("");
}
export function readThreads(storage: Storage): ChatThread[] {
  const saved = storage.getItem(THREADS_KEY);
  if (saved !== null) {
    const parsed: unknown = JSON.parse(saved);
    if (!Array.isArray(parsed)) return [];
    return parsed.filter(
      (t): t is ChatThread =>
        typeof t === "object" &&
        t !== null &&
        typeof t.id === "string" &&
        typeof t.title === "string" &&
        typeof t.updatedAt === "number" &&
        Array.isArray(t.messages) &&
        t.messages.every(
          (m: UIMessage) =>
            m &&
            typeof m.id === "string" &&
            ["user", "assistant"].includes(m.role) &&
            Array.isArray(m.parts),
        ),
    );
  }
  const old: unknown = JSON.parse(storage.getItem("n8n-chat:history") || "[]");
  const threads: ChatThread[] = [];
  if (Array.isArray(old) && old.length) {
    const messages: UIMessage[] = old
      .filter((m) => m && ["user", "assistant"].includes(m.role) && typeof m.content === "string")
      .map((m) => ({
        id: crypto.randomUUID(),
        role: m.role,
        parts: [{ type: "text", text: m.content }],
      }));
    if (messages.length)
      threads.push({
        id: storage.getItem("n8n-chat:session-id") || crypto.randomUUID(),
        title: (messages[0] ? messageText(messages[0]).slice(0, 50) : "") || "Previous chat",
        updatedAt: Date.now(),
        messages,
      });
  }
  storage.setItem(THREADS_KEY, JSON.stringify(threads));
  return threads;
}
