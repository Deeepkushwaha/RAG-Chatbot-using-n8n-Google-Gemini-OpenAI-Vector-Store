import { createContext, useContext, useEffect, useRef, useState, type ReactNode } from "react";
import type { UIMessage } from "ai";
import {
  makeThread,
  messageText,
  readThreads,
  THREADS_KEY,
  WEBHOOK_KEY,
  type ChatThread,
} from "@/lib/chat-store";

type ChatContextValue = {
  ready: boolean;
  threads: ChatThread[];
  webhook: string;
  pending: string[];
  errors: Record<string, string>;
  storageError: string | null;
  create: () => ChatThread;
  rename: (id: string, title: string) => void;
  remove: (id: string) => void;
  editMessage: (id: string, messageId: string, text: string) => void;
  deleteMessage: (id: string, messageId: string) => void;
  connect: (url: string) => void;
  send: (id: string, text: string) => Promise<void>;
};
const ChatContext = createContext<ChatContextValue | null>(null);
export function ChatProvider({ children }: { children: ReactNode }) {
  const [threads, setThreads] = useState<ChatThread[]>([]);
  const threadsRef = useRef<ChatThread[]>([]);
  const busy = useRef(new Set<string>());
  const [pending, setPending] = useState<string[]>([]);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [storageError, setStorageError] = useState<string | null>(null);
  const [webhook, setWebhook] = useState("");
  const [ready, setReady] = useState(false);
  useEffect(() => {
    try {
      threadsRef.current = readThreads(localStorage);
      setThreads(threadsRef.current);
      setWebhook(localStorage.getItem(WEBHOOK_KEY) || "");
    } catch {
      setStorageError("Browser history load nahi hui. Browser storage check karein.");
    }
    setReady(true);
  }, []);
  function update(transform: (items: ChatThread[]) => ChatThread[]) {
    const next = transform(threadsRef.current);
    threadsRef.current = next;
    setThreads(next);
    try {
      localStorage.setItem(THREADS_KEY, JSON.stringify(next));
    } catch {
      setStorageError("History save nahi ho rahi. Browser storage full ya blocked hai.");
    }
  }
  function create() {
    const thread = makeThread();
    update((items) => [thread, ...items]);
    return thread;
  }
  function rename(id: string, title: string) {
    update((items) =>
      items.map((t) => (t.id === id ? { ...t, title: title.trim() || "New chat" } : t)),
    );
  }
  function remove(id: string) {
    update((items) => items.filter((t) => t.id !== id));
  }
  function editMessage(id: string, messageId: string, text: string) {
    update((items) =>
      items.map((t) =>
        t.id === id
          ? {
              ...t,
              messages: t.messages.map((m) =>
                m.id === messageId ? { ...m, parts: [{ type: "text" as const, text }] } : m,
              ),
            }
          : t,
      ),
    );
  }
  function deleteMessage(id: string, messageId: string) {
    update((items) =>
      items.map((t) =>
        t.id === id ? { ...t, messages: t.messages.filter((m) => m.id !== messageId) } : t,
      ),
    );
  }
  function connect(url: string) {
    setWebhook(url);
    try {
      if (url) localStorage.setItem(WEBHOOK_KEY, url);
      else localStorage.removeItem(WEBHOOK_KEY);
    } catch {
      setStorageError("Connection browser mein save nahi ho paya.");
    }
  }
  async function send(id: string, text: string) {
    if (!text.trim() || !webhook || busy.current.has(id)) return;
    busy.current.add(id);
    setPending([...busy.current]);
    setErrors((prev) => ({ ...prev, [id]: "" }));
    const user: UIMessage = {
      id: crypto.randomUUID(),
      role: "user",
      parts: [{ type: "text", text }],
    };
    update((items) =>
      items.map((t) =>
        t.id === id
          ? {
              ...t,
              title: t.messages.length ? t.title : text.slice(0, 50),
              updatedAt: Date.now(),
              messages: [...t.messages, user],
            }
          : t,
      ),
    );
    try {
      const res = await fetch("/api/public/n8n-chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url: webhook, message: text, sessionId: id }),
      });
      const data = (await res.json()) as { reply?: string; error?: string };
      if (!res.ok || data.error || !data.reply?.trim())
        throw new Error(data.error || "n8n se jawab nahi mila. Workflow check karein.");
      const reply: UIMessage = {
        id: crypto.randomUUID(),
        role: "assistant",
        parts: [{ type: "text", text: data.reply }],
      };
      update((items) =>
        items.map((t) =>
          t.id === id ? { ...t, updatedAt: Date.now(), messages: [...t.messages, reply] } : t,
        ),
      );
    } catch (e) {
      setErrors((prev) => ({
        ...prev,
        [id]: e instanceof Error ? e.message : "Message nahi bhej paye. Dobara try karein.",
      }));
    } finally {
      busy.current.delete(id);
      setPending([...busy.current]);
    }
  }
  return (
    <ChatContext.Provider
      value={{
        ready,
        threads,
        webhook,
        pending,
        errors,
        storageError,
        create,
        rename,
        remove,
        editMessage,
        deleteMessage,
        connect,
        send,
      }}
    >
      {children}
    </ChatContext.Provider>
  );
}
export function useChats() {
  const context = useContext(ChatContext);
  if (!context) throw new Error("ChatProvider required");
  return context;
}
