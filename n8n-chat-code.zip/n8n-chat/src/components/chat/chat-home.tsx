import { useEffect, useRef, useState } from "react";
import { Link, useNavigate } from "@tanstack/react-router";
import {
  ArrowUp,
  Check,
  ChevronDown,
  Copy,
  Link2,
  MessageSquare,
  MoreHorizontal,
  PanelLeft,
  Pencil,
  Plus,
  Search,
  Settings2,
  Trash2,
  X,
  Workflow,
  ArrowUpRight,
  Loader2,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Conversation,
  ConversationContent,
  ConversationScrollButton,
} from "@/components/ai-elements/conversation";
import {
  Message,
  MessageContent,
  MessageResponse,
  MessageActions,
  MessageAction,
} from "@/components/ai-elements/message";
import {
  PromptInput,
  PromptInputTextarea,
  PromptInputFooter,
  PromptInputSubmit,
} from "@/components/ai-elements/prompt-input";
import { Shimmer } from "@/components/ai-elements/shimmer";
import { useChats } from "./chat-provider";
import { messageText } from "@/lib/chat-store";
import mark from "@/assets/chat-mark.svg";

export function ChatHome({ threadId }: { threadId?: string }) {
  const chat = useChats();
  const navigate = useNavigate();
  const thread = chat.threads.find((t) => t.id === threadId);
  const [sidebar, setSidebar] = useState(false);
  const [search, setSearch] = useState("");
  const [settings, setSettings] = useState(false);
  const [url, setUrl] = useState("");
  const [urlError, setUrlError] = useState("");
  const [renameId, setRenameId] = useState<string | null>(null);
  const [title, setTitle] = useState("");
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [input, setInput] = useState("");
  const [editing, setEditing] = useState<string | null>(null);
  const [editText, setEditText] = useState("");
  const [copied, setCopied] = useState<string | null>(null);
  const composer = useRef<HTMLTextAreaElement>(null);
  const sending = !!threadId && chat.pending.includes(threadId);
  const empty = !thread?.messages.length;
  useEffect(() => {
    if (!settings && !renameId && !deleteId && !editing && !sending) composer.current?.focus();
  }, [threadId, settings, renameId, deleteId, editing, sending, chat.ready]);
  function newChat() {
    const t = chat.create();
    setSidebar(false);
    void navigate({ to: "/chat/$threadId", params: { threadId: t.id } });
  }
  function openSettings() {
    setUrl(chat.webhook);
    setUrlError("");
    setSettings(true);
  }
  function connect() {
    try {
      const parsed = new URL(url.trim());
      if (!["http:", "https:"].includes(parsed.protocol)) throw new Error();
      chat.connect(url.trim());
      setSettings(false);
    } catch {
      setUrlError("Sahi http:// ya https:// Production URL daalein.");
    }
  }
  async function send(text: string) {
    if (!text.trim() || sending) return;
    if (!chat.webhook) {
      openSettings();
      return;
    }
    if (threadId && !thread) return;
    const active = thread || chat.create();
    if (!thread) void navigate({ to: "/chat/$threadId", params: { threadId: active.id } });
    setInput("");
    composer.current?.focus();
    await chat.send(active.id, text.trim());
    composer.current?.focus();
  }
  const filtered = [...chat.threads]
    .sort((a, b) => b.updatedAt - a.updatedAt)
    .filter((t) =>
      `${t.title} ${t.messages.map(messageText).join(" ")}`
        .toLowerCase()
        .includes(search.toLowerCase()),
    );
  const groups = [
    {
      title: "Today",
      items: filtered.filter(
        (t) => new Date(t.updatedAt).toDateString() === new Date().toDateString(),
      ),
    },
    {
      title: "Previous chats",
      items: filtered.filter(
        (t) => new Date(t.updatedAt).toDateString() !== new Date().toDateString(),
      ),
    },
  ];
  return (
    <div className="flex h-dvh overflow-hidden bg-background">
      {sidebar && (
        <Button
          variant="ghost"
          className="fixed inset-0 z-30 h-full w-full rounded-none bg-background/70 md:hidden"
          aria-label="Close sidebar"
          onClick={() => setSidebar(false)}
        />
      )}
      <aside
        className={`fixed inset-y-0 left-0 z-40 flex w-64 shrink-0 flex-col border-r border-border/60 bg-sidebar transition-transform md:static md:translate-x-0 ${sidebar ? "translate-x-0" : "-translate-x-full"}`}
      >
        <div className="flex h-20 items-center justify-between px-5">
          <Link to="/" className="flex items-center gap-2.5">
            <img src={mark} alt="" className="size-8" />
            <span className="font-display text-lg font-semibold">
              n8n<span className="font-normal text-muted-foreground"> chat</span>
            </span>
          </Link>
          <Button
            variant="ghost"
            size="icon-sm"
            title="Close sidebar"
            aria-label="Close sidebar"
            onClick={() => setSidebar(false)}
            className="md:hidden"
          >
            <X />
          </Button>
        </div>
        <div className="px-3">
          <Button
            onClick={newChat}
            variant="outline"
            className="h-11 w-full justify-start gap-3 border-border bg-card/60"
          >
            <Plus className="text-primary" />
            New chat
          </Button>
          <div className="relative mt-4">
            <Search className="absolute left-3 top-2.5 size-4 text-muted-foreground" />
            <Input
              aria-label="Search chats"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search chats"
              className="h-9 border-transparent bg-transparent pl-9 shadow-none focus-visible:border-input"
            />
          </div>
        </div>
        <nav aria-label="Chat history" className="min-h-0 flex-1 overflow-y-auto px-3 pb-5 pt-5">
          {groups.map(
            (group) =>
              group.items.length > 0 && (
                <div key={group.title} className="mb-6">
                  <h2 className="mb-2 px-3 text-[11px] font-medium uppercase tracking-widest text-muted-foreground">
                    {group.title}
                  </h2>
                  {group.items.map((t) => (
                    <div
                      key={t.id}
                      className={`group mb-1 flex h-10 items-center rounded-md ${t.id === threadId ? "bg-accent" : "hover:bg-accent/50"}`}
                    >
                      <Link
                        to="/chat/$threadId"
                        params={{ threadId: t.id }}
                        onClick={() => setSidebar(false)}
                        className="flex min-w-0 flex-1 items-center gap-2.5 px-3 text-[13px]"
                      >
                        <MessageSquare className="size-3.5 shrink-0 text-muted-foreground" />
                        <span className="truncate">{t.title}</span>
                      </Link>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button
                            variant="ghost"
                            size="icon-sm"
                            aria-label={`Options for ${t.title}`}
                            className="mr-1 shrink-0 text-muted-foreground"
                          >
                            <MoreHorizontal />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="start">
                          <DropdownMenuItem
                            onSelect={() => {
                              setRenameId(t.id);
                              setTitle(t.title);
                            }}
                          >
                            <Pencil />
                            Rename chat
                          </DropdownMenuItem>
                          <DropdownMenuItem
                            onSelect={() => setDeleteId(t.id)}
                            className="text-destructive"
                          >
                            <Trash2 />
                            Delete chat
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  ))}
                </div>
              ),
          )}
          {filtered.length === 0 && (
            <p className="px-3 py-3 text-xs text-muted-foreground">
              {search ? "No chats found" : "No conversations yet"}
            </p>
          )}
        </nav>
        <div className="border-t border-border/60 p-3">
          <Button
            variant="ghost"
            onClick={openSettings}
            className="h-11 w-full justify-start text-muted-foreground"
          >
            <Settings2 />
            Settings
            <span
              className={`ml-auto size-1.5 rounded-full ${chat.webhook ? "bg-success" : "bg-muted-foreground"}`}
            />
          </Button>
          <div className="mt-2 flex items-center gap-3 px-3 py-3">
            <span className="flex size-8 items-center justify-center rounded-full bg-secondary text-xs font-semibold">
              DK
            </span>
            <div>
              <p className="text-xs font-medium">Your workspace</p>
              <p className="mt-0.5 text-[10px] text-muted-foreground">Personal</p>
            </div>
          </div>
        </div>
      </aside>
      <main className="relative flex min-w-0 flex-1 flex-col">
        <header className="flex h-20 shrink-0 items-center justify-between gap-3 px-5 sm:px-8">
          <div className="flex min-w-0 items-center gap-3">
            <Button
              variant="ghost"
              size="icon"
              aria-label="Open sidebar"
              title="Chat history"
              onClick={() => setSidebar(true)}
              className="md:hidden"
            >
              <PanelLeft />
            </Button>
            <span className="truncate text-sm font-medium">
              {thread?.title && !empty ? thread.title : "n8n Chat"}
            </span>
            <ChevronDown className="size-3.5 text-muted-foreground" />
          </div>
          <div className="flex items-center gap-3">
            <span className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
              <span
                className={`size-1.5 rounded-full ${chat.webhook ? "bg-success" : "bg-muted-foreground"}`}
              />
              {chat.webhook ? "Connected" : "Not connected"}
            </span>
            <Button
              variant="ghost"
              size="icon-sm"
              aria-label="Connection settings"
              title="Connection settings"
              onClick={openSettings}
            >
              <Settings2 />
            </Button>
          </div>
        </header>
        {!chat.ready ? (
          <div className="flex flex-1 items-center justify-center">
            <Loader2 className="size-5 animate-spin text-muted-foreground" />
          </div>
        ) : threadId && !thread ? (
          <div className="flex flex-1 flex-col items-center justify-center gap-4">
            <h1 className="font-display text-2xl">Chat not found</h1>
            <Button onClick={newChat}>
              <Plus />
              New chat
            </Button>
          </div>
        ) : (
          <>
            {empty ? (
              <div className="flex min-h-0 flex-1 flex-col justify-center px-5 pb-6">
                <div className="mx-auto w-full max-w-2xl">
                  <div className="mb-7 flex items-center gap-2 text-xs text-muted-foreground">
                    <span className="h-px w-6 bg-primary" />
                    YOUR IDEAS, IN MOTION
                  </div>
                  <img src={mark} alt="n8n workflow" className="mb-5 size-16" />
                  <h1 className="font-display text-3xl font-medium leading-tight sm:text-4xl">
                    What’s on your mind?
                  </h1>
                  <p className="mt-3 text-sm text-muted-foreground">
                    A fresh conversation. A new possibility.
                  </p>
                  <div className="mt-9 grid grid-cols-1 gap-2 sm:grid-cols-3">
                    {[
                      {
                        icon: Workflow,
                        label: "Plan a workflow",
                        text: "Help me plan a useful n8n workflow.",
                      },
                      {
                        icon: Pencil,
                        label: "Create something",
                        text: "Help me brainstorm something creative.",
                      },
                      {
                        icon: MessageSquare,
                        label: "Ask a question",
                        text: "What can you help me with today?",
                      },
                    ].map((s) => (
                      <Button
                        key={s.label}
                        variant="outline"
                        onClick={() => {
                          setInput(s.text);
                          composer.current?.focus();
                        }}
                        className="h-auto min-h-20 items-start justify-start gap-3 whitespace-normal border-border bg-transparent p-4 text-left"
                      >
                        <s.icon className="mt-0.5 text-primary" />
                        <span className="flex-1 text-xs font-normal">{s.label}</span>
                        <ArrowUpRight className="size-3 text-muted-foreground" />
                      </Button>
                    ))}
                  </div>
                </div>
              </div>
            ) : (
              <Conversation key={threadId} className="min-h-0">
                <ConversationContent className="mx-auto w-full max-w-3xl gap-7 px-5 pb-8 pt-4 sm:px-8">
                  {thread?.messages.map((m) => (
                    <Message key={m.id} from={m.role} className="message-in max-w-full">
                      {m.role === "assistant" && (
                        <div className="mb-1 flex items-center gap-2 text-xs font-medium">
                          <img src={mark} alt="" className="size-6" />
                          n8n<span className="font-normal text-muted-foreground">Assistant</span>
                        </div>
                      )}
                      <MessageContent
                        className={
                          m.role === "user"
                            ? "group-[.is-user]:max-w-[90%] group-[.is-user]:bg-chat-user group-[.is-user]:text-chat-user-foreground"
                            : "w-full text-sm"
                        }
                      >
                        {m.parts.map((p, i) =>
                          p.type === "text" ? (
                            m.role === "assistant" ? (
                              <MessageResponse key={i} className="chat-response">
                                {p.text}
                              </MessageResponse>
                            ) : (
                              <span key={i} className="whitespace-pre-wrap break-words">
                                {p.text}
                              </span>
                            )
                          ) : null,
                        )}
                      </MessageContent>
                      <MessageActions
                        className={
                          m.role === "user"
                            ? "justify-end text-muted-foreground"
                            : "text-muted-foreground"
                        }
                      >
                        <MessageAction
                          tooltip={copied === m.id ? "Copied" : "Copy message"}
                          onClick={async () => {
                            try {
                              await navigator.clipboard.writeText(messageText(m));
                              setCopied(m.id);
                            } catch {
                              setCopied(null);
                            }
                          }}
                        >
                          {copied === m.id ? (
                            <Check className="size-3.5" />
                          ) : (
                            <Copy className="size-3.5" />
                          )}
                        </MessageAction>
                        <MessageAction
                          tooltip="Edit message"
                          disabled={sending}
                          onClick={() => {
                            setEditing(m.id);
                            setEditText(messageText(m));
                          }}
                        >
                          <Pencil className="size-3.5" />
                        </MessageAction>
                        <MessageAction
                          tooltip="Delete message"
                          disabled={sending}
                          onClick={() => {
                            if (threadId) chat.deleteMessage(threadId, m.id);
                          }}
                        >
                          <Trash2 className="size-3.5" />
                        </MessageAction>
                      </MessageActions>
                    </Message>
                  ))}
                  {sending && (
                    <div role="status" className="flex items-center gap-3">
                      <img src={mark} alt="" className="size-6" />
                      <Shimmer className="text-sm">Thinking...</Shimmer>
                    </div>
                  )}
                </ConversationContent>
                <ConversationScrollButton />
              </Conversation>
            )}
            <div
              className={`mx-auto w-full max-w-3xl shrink-0 px-5 pb-5 sm:px-8 ${empty ? "max-w-[736px]" : ""}`}
            >
              {(chat.storageError || (threadId && chat.errors[threadId])) && (
                <p
                  role="alert"
                  className="mb-3 rounded-md border border-destructive/30 bg-destructive/10 p-3 text-sm text-destructive"
                >
                  {chat.storageError || (threadId && chat.errors[threadId])}
                </p>
              )}
              <PromptInput className="chat-composer" onSubmit={({ text }) => send(text)}>
                <PromptInputTextarea
                  ref={composer}
                  aria-label="Message"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder="Message your n8n assistant…"
                  maxLength={10000}
                  className="min-h-16 px-5 pt-4"
                />
                <PromptInputFooter>
                  <span className="flex items-center gap-2 text-[11px] text-muted-foreground">
                    <img src={mark} alt="" className="size-5" />
                    n8n Assistant
                  </span>
                  <PromptInputSubmit
                    status={sending ? "submitted" : "ready"}
                    disabled={!input.trim() || sending}
                    aria-label="Send message"
                    className="size-9 rounded-lg"
                  >
                    {!sending && <ArrowUp className="size-4" />}
                  </PromptInputSubmit>
                </PromptInputFooter>
              </PromptInput>
              <p className="mt-3 text-center text-[10px] text-muted-foreground">
                n8n Chat · Personal workspace
              </p>
            </div>
          </>
        )}
      </main>
      <Dialog open={settings} onOpenChange={setSettings}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Link2 className="size-5 text-primary" />
              n8n connection
            </DialogTitle>
            <DialogDescription>
              {chat.webhook ? "Your workflow is connected." : "Connect your n8n workflow."}
            </DialogDescription>
          </DialogHeader>
          <label htmlFor="webhook" className="text-xs font-medium">
            Production webhook URL
          </label>
          <Input
            id="webhook"
            type="url"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            placeholder="https://your-n8n/webhook/…"
            onKeyDown={(e) => {
              if (e.key === "Enter") connect();
            }}
          />
          {urlError && (
            <p role="alert" className="text-xs text-destructive">
              {urlError}
            </p>
          )}
          <DialogFooter>
            {chat.webhook && (
              <Button
                variant="ghost"
                onClick={() => {
                  chat.connect("");
                  setSettings(false);
                }}
              >
                Disconnect
              </Button>
            )}
            <Button onClick={connect}>Save connection</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      <Dialog
        open={!!renameId}
        onOpenChange={(open) => {
          if (!open) setRenameId(null);
        }}
      >
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>Rename chat</DialogTitle>
            <DialogDescription>Give this conversation a name.</DialogDescription>
          </DialogHeader>
          <Input
            aria-label="Chat name"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            maxLength={80}
          />
          <DialogFooter>
            <Button
              onClick={() => {
                if (renameId) chat.rename(renameId, title);
                setRenameId(null);
              }}
              disabled={!title.trim()}
            >
              Save
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      <Dialog
        open={!!deleteId}
        onOpenChange={(open) => {
          if (!open) setDeleteId(null);
        }}
      >
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>Delete chat?</DialogTitle>
            <DialogDescription>
              This conversation will be permanently deleted from this browser.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setDeleteId(null)}>
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={() => {
                if (deleteId) chat.remove(deleteId);
                if (deleteId === threadId) void navigate({ to: "/" });
                setDeleteId(null);
              }}
            >
              Delete chat
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      <Dialog
        open={!!editing}
        onOpenChange={(open) => {
          if (!open) setEditing(null);
        }}
      >
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Edit message</DialogTitle>
            <DialogDescription>
              Update the saved message. Existing replies stay unchanged.
            </DialogDescription>
          </DialogHeader>
          <Textarea
            aria-label="Edit message text"
            value={editText}
            onChange={(e) => setEditText(e.target.value)}
            className="min-h-32"
            maxLength={10000}
          />
          <DialogFooter>
            <Button variant="ghost" onClick={() => setEditing(null)}>
              Cancel
            </Button>
            <Button
              disabled={!editText.trim()}
              onClick={() => {
                if (threadId && editing) chat.editMessage(threadId, editing, editText.trim());
                setEditing(null);
              }}
            >
              Save changes
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
